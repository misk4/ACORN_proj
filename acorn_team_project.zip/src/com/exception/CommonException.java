package com.exception;

public class CommonException extends Exception {

	public CommonException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
