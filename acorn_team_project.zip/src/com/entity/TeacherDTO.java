package com.entity;

public class TeacherDTO extends MemberDTO{

	public TeacherDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TeacherDTO(String id, String name, String birthdate, String password, String gender, String phonenum,
			String email) {
		super(id, name, birthdate, password, gender, phonenum, email);
		// TODO Auto-generated constructor stub
	}
		
		
	
		
	
}
