package com.entity;

public class ManagerDTO extends MemberDTO{

	public ManagerDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ManagerDTO(String id, String name, String birthdate, String password, String gender, String phonenum,
			String email) {
		super(id, name, birthdate, password, gender, phonenum, email);
		// TODO Auto-generated constructor stub
	}

	
	
}
